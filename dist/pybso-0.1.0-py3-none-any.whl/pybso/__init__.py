#!/usr/bin/env python
# -*- coding: utf-8 -*-

"""
    This package automates the harvesting and graphic formatting of data 
    related to the opening of a set of publications identified by their doi.
"""
__version__ = "0.1.0"